# OTRSP controller

## Building
```console
$ git clone git@github.com:Staszyslaw/otrsp.git
$ cd otrsp
$ mkdir release
$ cmake -S . -B Release -D CMAKE_BUILD_TYPE=Release
$ cmake --build Release
$ ./release/otrsp
```

## Requirements
qt6
cmake
make
gcc
